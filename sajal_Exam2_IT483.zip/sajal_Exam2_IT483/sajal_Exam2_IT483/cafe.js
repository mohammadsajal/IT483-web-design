$(document).ready(function () {
    var total = 0;

    $("ul img").each(function () {

        $(this).hover(function ()
        {
            $(this).attr("src", this.id);
        
        }, function () {
            var image = (this.id).split("_");
            $(this).attr("src", image[0]+".jpg");
        });
      
        $(this).click(function (check)
        {          
            var total=0.00;
            var strTotal = document.getElementById("total").textContent;
           
            if (strTotal.length < 3)
            {
                total = 0.00;           
            }
            else
            {              
                var getTotal = strTotal.substr(strTotal.indexOf("$") + 1, strTotal.length);               
                total = parseFloat(getTotal);
            }
          
            var drink = this.id;
            if (drink == "images/espresso_info.jpg")
            {               
                $('#cal').append($('<option></option>').html("$1.95 - Espresso"));
                total = total + 1.95;
            }
            else if (drink == "images/latte_info.jpg")
            {
                $('#cal').append($('<option></option>').html("$2.95 - Latte"));
                total = total + 2.95;
            }
            else if (drink == "images/cappuccino_info.jpg")
            {
                $('#cal').append($('<option></option>').html("$3.45 - Cappuccino"));
                total = total + 3.45;               
            }
            else if (drink == "images/coffee_info.jpg")
            {
                $('#cal').append($('<option></option>').html("$1.75 - Coffee"));
                total = total + 1.75;
            }
            else if (drink == "images/biscotti_info.jpg")
            {
                $('#cal').append($('<option></option>').html("$1.95 - Biscotti"));
                total = total + 1.95;
            }
            else
            {
                $('#cal').append($('<option></option>').html("$2.95 - Scone"));
                total = total + 2.95;
            }
            document.getElementById("total").textContent = "Total: $" + total.toFixed(2);
            check.preventDefault();

        }); 
    }); 

    $("#PlaceOrder").click(function () {

        window.location.href = 'checkout.html';
    });

    $("#ClearOrder").click(function () {

        $('#cal').empty();
        $("#total")[0].innerHTML = " ";
        total = 0;
    });

});
